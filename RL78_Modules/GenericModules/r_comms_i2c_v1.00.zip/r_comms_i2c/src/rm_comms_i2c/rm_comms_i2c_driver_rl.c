/* ${REA_DISCLAIMER_PLACEHOLDER} */

/*******************************************************************************************************************//**
 * Includes
 **********************************************************************************************************************/
#include "r_comms_i2c_if.h"

/*******************************************************************************************************************//**
 * Macro definitions
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * Typedef definitions
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * Private function prototypes
 **********************************************************************************************************************/
static void rm_comms_i2c_process_in_callback(rm_comms_ctrl_t * const          p_api_ctrl,
                                             rm_comms_callback_args_t * const p_args);
/*******************************************************************************************************************//**
 * Private global variables
 **********************************************************************************************************************/
fsp_err_t rm_comms_i2c_bus_status_check(rm_comms_ctrl_t * const p_api_ctrl);
fsp_err_t rm_comms_i2c_bus_read(rm_comms_ctrl_t * const p_api_ctrl, uint8_t * const p_dest, uint32_t const bytes);
fsp_err_t rm_comms_i2c_bus_write(rm_comms_ctrl_t * const p_api_ctrl, uint8_t * const p_src, uint32_t const bytes);
fsp_err_t rm_comms_i2c_bus_write_read(rm_comms_ctrl_t * const            p_api_ctrl,
                                      rm_comms_write_read_params_t const write_read_params);

/*******************************************************************************************************************//**
 * Global variables
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * Functions
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Checks if the I2C driver module is open.
 *
 * @retval FSP_SUCCESS                  successfully configured. (The bus of RL78 is always opened by initialization)
 **********************************************************************************************************************/
fsp_err_t rm_comms_i2c_bus_status_check(rm_comms_ctrl_t * const p_api_ctrl)
{
    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 * Function Name: rm_comms_i2c_bus_read
 * @brief Read data from the device using the I2C driver module.
 * @param[in]  p_api_ctrl           Pointer to instance control structure
 *             p_dest               Pointer to destination buffer
 *             bytes                Number of destination data
 * @retval FSP_SUCCESS              successfully started.
 ***********************************************************************************************************************/
fsp_err_t rm_comms_i2c_bus_read (rm_comms_ctrl_t * const p_api_ctrl, uint8_t * const p_dest, uint32_t const bytes)
{
    fsp_err_t                      err               = FSP_SUCCESS;
    rm_comms_i2c_instance_ctrl_t * p_ctrl            = (rm_comms_i2c_instance_ctrl_t *) p_api_ctrl;
    i2c_driver_instance_t        * p_driver_instance = (i2c_driver_instance_t *) p_ctrl->p_bus->p_driver_instance;
    rm_comms_i2c_device_cfg_t    * p_device_cfg      = (rm_comms_i2c_device_cfg_t *) p_ctrl->p_cfg->p_lower_level_cfg;

    /* Clear transfer data */
    p_ctrl->p_transfer_data     = NULL;
    p_ctrl->transfer_data_bytes = 0;

    if (COMMS_DRIVER_I2C == p_driver_instance->driver_type)
    {
#if (COMMS_I2C_CFG_DRIVER_I2C)
        iica_api_t * p_iica_api  = (iica_api_t *)p_driver_instance->p_api;
        MD_STATUS    status;
        uint8_t      wait = 0xFF;

        status = (p_iica_api->read)((p_device_cfg->slave_address << 1), p_dest, bytes, wait);
        switch (status)
        {
            case MD_OK:
                err = FSP_SUCCESS;
                break;
            case MD_ERROR1:
            case MD_ERROR2:
                err = FSP_ERR_IN_USE;
                break;
            default:
                err = FSP_ERR_ABORTED;
                break;
        }
        FSP_ERROR_RETURN(FSP_SUCCESS == err, err);
#endif
    }
    else if (COMMS_DRIVER_SAU_I2C == p_driver_instance->driver_type)
    {
#if (COMMS_I2C_CFG_DRIVER_SAU_I2C)
        sau_api_t * p_sau_api = (sau_api_t *)p_driver_instance->p_api;

        (p_sau_api->read)((p_device_cfg->slave_address << 1), p_dest, bytes);

        FSP_ERROR_RETURN(FSP_SUCCESS == err, err);
#endif
    }

    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 * Function Name: comms_i2c_driver_write
 * @brief Write data to the device using the I2C driver module.
 * @param[in]  p_api_ctrl           Pointer to instance control structure
 *             p_src                Pointer to source buffer
 *             bytes                Number of source data
 * @retval FSP_SUCCESS              Successfully started.
 ***********************************************************************************************************************/
fsp_err_t rm_comms_i2c_bus_write(rm_comms_ctrl_t * const p_api_ctrl, uint8_t * const p_src, uint32_t const bytes)
{
    fsp_err_t                      err               = FSP_SUCCESS;
    rm_comms_i2c_instance_ctrl_t * p_ctrl            = (rm_comms_i2c_instance_ctrl_t *) p_api_ctrl;
    i2c_driver_instance_t        * p_driver_instance = (i2c_driver_instance_t *) p_ctrl->p_bus->p_driver_instance;
    rm_comms_i2c_device_cfg_t    * p_device_cfg      = (rm_comms_i2c_device_cfg_t *) p_ctrl->p_cfg->p_lower_level_cfg;

    /* Clear transfer data */
    p_ctrl->p_transfer_data     = NULL;
    p_ctrl->transfer_data_bytes = 0;

    if (COMMS_DRIVER_I2C == p_driver_instance->driver_type)
    {
#if (COMMS_I2C_CFG_DRIVER_I2C)
        iica_api_t * p_iica_api  = (iica_api_t *)p_driver_instance->p_api;
        MD_STATUS    status;
        uint8_t      wait = 0xFF;

        status = (p_iica_api->write)((p_device_cfg->slave_address << 1), p_src, bytes, wait);
        switch (status)
        {
            case MD_OK:
                err = FSP_SUCCESS;
                break;
            case MD_ERROR1:
            case MD_ERROR2:
                err = FSP_ERR_IN_USE;
                break;
            default:
                err = FSP_ERR_ABORTED;
                break;
        }
        FSP_ERROR_RETURN(FSP_SUCCESS == err, err);
#endif
    }
    else if (COMMS_DRIVER_SAU_I2C == p_driver_instance->driver_type)
    {
#if (COMMS_I2C_CFG_DRIVER_SAU_I2C)
        sau_api_t * p_sau_api = (sau_api_t *)p_driver_instance->p_api;

        (p_sau_api->write)((p_device_cfg->slave_address << 1), p_src, bytes);

        FSP_ERROR_RETURN(FSP_SUCCESS == err, err);
#endif
    }

    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 * Function Name: rm_comms_i2c_driver_write_read
 * @brief Writes to I2C bus, then reads with restart.
 * @param[in]  p_api_ctrl           Pointer to instance control structure
 *             write_read_params    Write / read buffer structure
 * @retval FSP_SUCCESS              Successfully started.
 ***********************************************************************************************************************/
fsp_err_t rm_comms_i2c_bus_write_read (rm_comms_ctrl_t * const p_api_ctrl, rm_comms_write_read_params_t write_read_params)
{
    fsp_err_t                      err               = FSP_SUCCESS;
    rm_comms_i2c_instance_ctrl_t * p_ctrl            = (rm_comms_i2c_instance_ctrl_t *) p_api_ctrl;
    i2c_driver_instance_t        * p_driver_instance = (i2c_driver_instance_t *) p_ctrl->p_bus->p_driver_instance;
    rm_comms_i2c_device_cfg_t    * p_device_cfg      = (rm_comms_i2c_device_cfg_t *) p_ctrl->p_cfg->p_lower_level_cfg;

    /* Set read data */
    p_ctrl->p_transfer_data     = write_read_params.p_dest;
    p_ctrl->transfer_data_bytes = write_read_params.dest_bytes;

    if (COMMS_DRIVER_I2C == p_driver_instance->driver_type)
    {
#if (COMMS_I2C_CFG_DRIVER_I2C)
        iica_api_t * p_iica_api  = (iica_api_t *)p_driver_instance->p_api;
        MD_STATUS    status;
        uint8_t      wait = 0xFF;

        status = (p_iica_api->write)((p_device_cfg->slave_address << 1), write_read_params.p_src, write_read_params.src_bytes, wait);
        switch (status)
        {
            case MD_OK:
                err = FSP_SUCCESS;
                break;
            case MD_ERROR1:
            case MD_ERROR2:
                err = FSP_ERR_IN_USE;
                break;
            default:
                err = FSP_ERR_ABORTED;
                break;
        }
        FSP_ERROR_RETURN(FSP_SUCCESS == err, err);
#endif
    }
    else if (COMMS_DRIVER_SAU_I2C == p_driver_instance->driver_type)
    {
#if (COMMS_I2C_CFG_DRIVER_SAU_I2C)
        sau_api_t * p_sau_api = (sau_api_t *)p_driver_instance->p_api;

        (p_sau_api->write)((p_device_cfg->slave_address << 1), write_read_params.p_src, write_read_params.src_bytes);

        FSP_ERROR_RETURN(FSP_SUCCESS == err, err);
#endif
    }

    return FSP_SUCCESS;
}

/*******************************************************************************************************************//**
 * Function Name: rm_comms_i2c_callback
 * @brief Common callback function called in the I2C driver callback function.
 * @param[in]  p_args                      Pointer to I2C callback arguments structure
 * @param[in]  p_api_ctrl                  Pointer to instance control structure
 ***********************************************************************************************************************/
void rm_comms_i2c_callback (rm_comms_ctrl_t const * p_api_ctrl, bool aborted)
{
    fsp_err_t                      err;
    rm_comms_i2c_instance_ctrl_t * p_ctrl            = (rm_comms_i2c_instance_ctrl_t *) p_api_ctrl;
    i2c_driver_instance_t        * p_driver_instance = (i2c_driver_instance_t *) p_ctrl->p_bus->p_driver_instance;
    rm_comms_callback_args_t       comms_i2c_args;

    /* Set error */
    if (false == aborted)
    {
        comms_i2c_args.event = RM_COMMS_EVENT_OPERATION_COMPLETE;
    }
    else
    {
        comms_i2c_args.event = RM_COMMS_EVENT_ERROR;
    }

    if ((NULL != p_ctrl->p_transfer_data)
        && (RM_COMMS_EVENT_OPERATION_COMPLETE == comms_i2c_args.event))
    {
        /* Read data with restart */
        err = rm_comms_i2c_bus_read(p_ctrl,
                                    p_ctrl->p_transfer_data,
                                    p_ctrl->transfer_data_bytes);

        if (FSP_SUCCESS != err)
        {
            /* Set event */
            comms_i2c_args.event = RM_COMMS_EVENT_ERROR;

            /* Release semaphore in OS and call user callback function */
            rm_comms_i2c_process_in_callback(p_ctrl, &comms_i2c_args);
        }
    }
    else
    {
        if (COMMS_DRIVER_I2C == p_driver_instance->driver_type)
        {
#if (COMMS_I2C_CFG_DRIVER_I2C)
            iica_api_t *            p_iica_api        = (iica_api_t *)p_driver_instance->p_api;

    	    /* Generate stop condition */
            (p_iica_api->stopCondition)();
#endif
        }
        else if (COMMS_DRIVER_SAU_I2C == p_driver_instance->driver_type)
        {
#if (COMMS_I2C_CFG_DRIVER_SAU_I2C)
            sau_api_t * p_sau_api = (sau_api_t *)p_driver_instance->p_api;

    	    /* Generate stop condition */
            (p_sau_api->stopCondition)();
#endif
        }

        /* Release semaphore in OS and call user callback function */
        rm_comms_i2c_process_in_callback(p_ctrl, &comms_i2c_args);
    }
}

/*******************************************************************************************************************//**
 * Private Functions
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * Internal Communications Middleware I2C driver private function.
 **********************************************************************************************************************/

/*******************************************************************************************************************//**
 * Function Name: rm_comms_i2c_process_in_callback
 * @brief Process in callback function. Release semaphores in RTOS and call user callback.
 * @param[in] p_api_ctrl            Pointer to instance control structure
 *            p_args                Pointer to callback arguments structure
 * @retval FSP_SUCCESS              Successfully started.
 ***********************************************************************************************************************/
 static void rm_comms_i2c_process_in_callback (rm_comms_ctrl_t * const          p_api_ctrl,
                                              rm_comms_callback_args_t * const p_args)
{
    rm_comms_i2c_instance_ctrl_t * p_ctrl = (rm_comms_i2c_instance_ctrl_t *) p_api_ctrl;
    {
        if (NULL != p_ctrl->p_callback)
        {
            /* Call user callback */
            p_ctrl->p_callback(p_args);
        }
    }
}

/******************************************************************************************************************//**
 * @} (end addtogroup r_comms_i2c)
 *********************************************************************************************************************/
